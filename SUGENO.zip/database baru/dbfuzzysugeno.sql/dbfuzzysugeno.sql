-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 23, 2015 at 11:22 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbfuzzysugeno`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_pengguna` int(255) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `hak_akses` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pengguna`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_pengguna`, `nama`, `email`, `username`, `password`, `jenis_kelamin`, `alamat`, `hak_akses`) VALUES
(6, 'Administrator', 'admin@yahoo.com', 'admin', 'admin', 'LAKI-LAKI', 'JAKARTA', 'ADMIN'),
(8, 'Toyib', 'toyib@gmail.com', 'toyib', 'toyib', 'LAKI-LAKI', 'jl.madu asli no.20', 'USER'),
(9, 'Fauzan', 'Fauzan_ganteng@yahoo.com', 'Fauzan', 'Fauzan', 'LAKI-LAKI', 'jl.zainal abidin pagar alam', 'USER'),
(12, 'afif', 'afif@gmail.com', 'afif', 'afif1234', 'LAKI-LAKI', 'jl.sidorejo lampung selatan', 'USER'),
(11, 'Ahmad', 'ahmad_oke@yahoo.com', 'ahmad', 'ahmad', 'LAKI-LAKI', 'jl.samudra pasai no.90 bekasi', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `defuzzy`
--

CREATE TABLE IF NOT EXISTS `defuzzy` (
  `idpasien` int(10) NOT NULL,
  `defuzzy` float NOT NULL,
  PRIMARY KEY (`idpasien`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `defuzzy`
--

INSERT INTO `defuzzy` (`idpasien`, `defuzzy`) VALUES
(99, 7.76536),
(100, 0),
(101, 7.76536),
(102, 6),
(171, 10),
(186, 10);

-- --------------------------------------------------------

--
-- Table structure for table `min`
--

CREATE TABLE IF NOT EXISTS `min` (
  `idpasien` int(10) NOT NULL,
  `idrule` varchar(10) NOT NULL,
  `min` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `min`
--


-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `idnilai` int(3) NOT NULL AUTO_INCREMENT,
  `idpasien` int(10) NOT NULL,
  `idvariabel` int(3) NOT NULL,
  `nilai` float NOT NULL,
  `predikat` varchar(30) NOT NULL,
  `nilai1` varchar(8) NOT NULL,
  `nilai2` varchar(8) NOT NULL,
  `nilai3` varchar(8) NOT NULL,
  PRIMARY KEY (`idnilai`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=756 ;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`idnilai`, `idpasien`, `idvariabel`, `nilai`, `predikat`, `nilai1`, `nilai2`, `nilai3`) VALUES
(753, 186, 31, 76, 'Rendah', '1', '0', '0'),
(754, 186, 32, 89, 'Rendah', '1', '0', '0'),
(755, 186, 33, 3, 'Rendah', '1', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `rule`
--

CREATE TABLE IF NOT EXISTS `rule` (
  `idrule` varchar(10) NOT NULL,
  `maka` varchar(50) NOT NULL,
  `daerah` int(1) NOT NULL,
  PRIMARY KEY (`idrule`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rule`
--

INSERT INTO `rule` (`idrule`, `maka`, `daerah`) VALUES
('R1', 'Negatif', 1),
('R2', 'Negatif', 1),
('R3', 'Positif', 3),
('R4', 'Negatif', 1),
('R5', 'Negatif', 1),
('R6', 'Positif', 3),
('R7', 'Negatif', 1),
('R8', 'Negatif', 1),
('R9', 'Pradiabetes', 2),
('R10', 'Negatif', 1),
('R11', 'Negatif', 1),
('R12', 'Positif', 3),
('R13', 'Negatif', 1),
('R14', 'Negatif', 1),
('R15', 'Negatif', 1),
('R16', 'Negatif', 1),
('R17', 'Negatif', 1),
('R18', 'Pradiabetes', 2),
('R19', 'Negatif', 1),
('R20', 'Negatif', 1),
('R21', 'Negatif', 1),
('R22', 'Pradiabetes', 2),
('R23', 'Pradiabetes', 2),
('R24', 'Pradiabetes', 2),
('R25', 'Pradiabetes', 2),
('R26', 'Positif', 3),
('R27', 'Positif', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_min`
--

CREATE TABLE IF NOT EXISTS `tmp_min` (
  `idpasien` int(10) NOT NULL,
  `idrule` varchar(10) NOT NULL,
  `min` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmp_min`
--

INSERT INTO `tmp_min` (`idpasien`, `idrule`, `min`) VALUES
(171, 'R8', 0.7),
(171, 'R7', 0),
(171, 'R6', 0),
(171, 'R5', 0.3),
(171, 'R4', 0),
(171, 'R3', 0),
(171, 'R2', 0),
(171, 'R1', 0),
(0, 'R2', 0.6),
(0, 'R3', 0.6),
(0, 'R3', 0.6),
(0, 'R2', 0.6),
(0, 'R2', 0.6),
(0, 'R3', 0.6),
(0, 'R3', 0.6),
(0, 'R2', 0.6),
(0, 'R2', 0.4),
(0, 'R3', 0.4),
(0, 'R11', 0.3),
(0, 'R12', 0.3),
(0, 'R14', 0.3),
(0, 'R15', 0.3),
(0, 'R17', 0.3),
(0, 'R18', 0.3),
(0, 'R20', 0.3),
(0, 'R21', 0.3),
(0, 'R23', 0.3),
(0, 'R24', 0.3),
(0, 'R26', 0.3),
(0, 'R27', 0.3),
(0, 'R14', 0.2),
(0, 'R15', 0.2),
(0, 'R17', 0.2),
(0, 'R18', 0.2),
(0, 'R23', 0.2),
(0, 'R24', 0.2),
(0, 'R26', 0.2),
(0, 'R27', 0.2),
(0, 'R1', 0.9),
(0, 'R2', 0.1),
(0, 'R3', 0.1),
(0, 'R14', 0.4),
(0, 'R15', 0.4),
(0, 'R17', 0.4),
(0, 'R18', 0.4),
(0, 'R23', 0.4),
(0, 'R24', 0.4),
(0, 'R26', 0.4),
(0, 'R27', 0.4),
(0, 'R14', 0.2),
(0, 'R15', 0.2),
(0, 'R17', 0.2),
(0, 'R18', 0.2),
(0, 'R23', 0.2),
(0, 'R24', 0.2),
(0, 'R26', 0.2),
(0, 'R27', 0.2),
(186, 'R27', 0),
(186, 'R26', 0),
(186, 'R25', 0),
(186, 'R24', 0),
(186, 'R23', 0),
(186, 'R22', 0),
(186, 'R21', 0),
(186, 'R20', 0),
(186, 'R19', 0),
(186, 'R18', 0),
(186, 'R17', 0),
(186, 'R16', 0),
(186, 'R15', 0),
(186, 'R14', 0),
(186, 'R13', 0),
(186, 'R12', 0),
(186, 'R11', 0),
(186, 'R10', 0),
(186, 'R9', 0),
(186, 'R8', 0),
(186, 'R7', 0),
(186, 'R6', 0),
(186, 'R5', 0),
(186, 'R4', 0),
(186, 'R3', 0),
(186, 'R2', 0),
(186, 'R1', 1),
(171, 'R27', 0),
(171, 'R26', 0),
(171, 'R25', 0),
(171, 'R24', 0),
(171, 'R23', 0),
(171, 'R22', 0),
(171, 'R21', 0),
(171, 'R20', 0),
(171, 'R19', 0),
(171, 'R18', 0),
(171, 'R17', 0),
(171, 'R16', 0),
(171, 'R15', 0),
(171, 'R14', 0),
(171, 'R13', 0),
(171, 'R12', 0),
(171, 'R11', 0),
(171, 'R10', 0),
(171, 'R9', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_rule`
--

CREATE TABLE IF NOT EXISTS `tmp_rule` (
  `idrule` varchar(10) NOT NULL,
  `idvariabel` int(3) NOT NULL,
  `rule1` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmp_rule`
--

INSERT INTO `tmp_rule` (`idrule`, `idvariabel`, `rule1`) VALUES
('R4', 32, 'Sedang'),
('R4', 31, 'Rendah'),
('R5', 31, 'Rendah'),
('R4', 33, 'Rendah'),
('R5', 33, 'Sedang'),
('R5', 32, 'Sedang'),
('R6', 32, 'Sedang'),
('R6', 31, 'Rendah'),
('R2', 32, 'Rendah'),
('R3', 31, 'Rendah'),
('R2', 33, 'Sedang'),
('R3', 33, 'Tinggi'),
('R3', 32, 'Rendah'),
('R1', 33, 'Rendah'),
('R1', 32, 'Rendah'),
('R1', 31, 'Rendah'),
('R2', 31, 'Rendah'),
('R6', 33, 'Tinggi'),
('R7', 31, 'Rendah'),
('R7', 32, 'Tinggi'),
('R7', 33, 'Rendah'),
('R8', 31, 'Rendah'),
('R8', 32, 'Tinggi'),
('R8', 33, 'Sedang'),
('R9', 31, 'Rendah'),
('R9', 32, 'Tinggi'),
('R9', 33, 'Tinggi'),
('R10', 31, 'Sedang'),
('R10', 32, 'Rendah'),
('R10', 33, 'Rendah'),
('R11', 31, 'Sedang'),
('R11', 32, 'Rendah'),
('R11', 33, 'Sedang'),
('R12', 31, 'Sedang'),
('R12', 32, 'Rendah'),
('R12', 33, 'Tinggi'),
('R13', 31, 'Sedang'),
('R13', 32, 'Sedang'),
('R13', 33, 'Rendah'),
('R14', 31, 'Sedang'),
('R14', 32, 'Sedang'),
('R14', 33, 'Sedang'),
('R15', 31, 'Sedang'),
('R15', 32, 'Sedang'),
('R15', 33, 'Tinggi'),
('R16', 31, 'Sedang'),
('R16', 32, 'Tinggi'),
('R16', 33, 'Rendah'),
('R17', 31, 'Sedang'),
('R17', 32, 'Tinggi'),
('R17', 33, 'Sedang'),
('R18', 31, 'Sedang'),
('R18', 32, 'Tinggi'),
('R18', 33, 'Tinggi'),
('R19', 31, 'Tinggi'),
('R19', 32, 'Rendah'),
('R19', 33, 'Rendah'),
('R20', 31, 'Tinggi'),
('R20', 32, 'Rendah'),
('R20', 33, 'Sedang'),
('R21', 31, 'Tinggi'),
('R21', 32, 'Rendah'),
('R21', 33, 'Tinggi'),
('R22', 31, 'Tinggi'),
('R22', 32, 'Sedang'),
('R22', 33, 'Rendah'),
('R23', 31, 'Tinggi'),
('R23', 32, 'Sedang'),
('R23', 33, 'Sedang'),
('R24', 31, 'Tinggi'),
('R24', 32, 'Sedang'),
('R24', 33, 'Tinggi'),
('R25', 31, 'Tinggi'),
('R25', 32, 'Tinggi'),
('R25', 33, 'Rendah'),
('R26', 31, 'Tinggi'),
('R26', 32, 'Tinggi'),
('R26', 33, 'Sedang'),
('R27', 31, 'Tinggi'),
('R27', 32, 'Tinggi'),
('R27', 33, 'Tinggi');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `idpasien` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  PRIMARY KEY (`idpasien`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=187 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idpasien`, `nama`, `alamat`, `email`) VALUES
(99, 'sadsa', 'sdaasd', 'yayan@gmail.com'),
(100, 'sadasd', 'sad', 'aldo@yahoo.com'),
(101, 'asdas', 'sad', 'aldo@yahoo.com'),
(102, 'sad', 'sadas', 'sadas@gmail.com'),
(171, 'afif', 'oke', 'oke@gmail.com'),
(186, 'afif', 'asdas', 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `variabel`
--

CREATE TABLE IF NOT EXISTS `variabel` (
  `idvariabel` int(3) NOT NULL AUTO_INCREMENT,
  `variabel` varchar(100) NOT NULL,
  `nilai1` varchar(10) NOT NULL,
  `nilai11` varchar(10) NOT NULL,
  `nilai2` varchar(10) NOT NULL,
  `nilai22` varchar(10) NOT NULL,
  `nilai3` varchar(10) DEFAULT NULL,
  `nilai33` varchar(10) DEFAULT NULL,
  `atr1` varchar(30) NOT NULL,
  `atr2` varchar(30) NOT NULL,
  `atr3` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idvariabel`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `variabel`
--

INSERT INTO `variabel` (`idvariabel`, `variabel`, `nilai1`, `nilai11`, `nilai2`, `nilai22`, `nilai3`, `nilai33`, `atr1`, `atr2`, `atr3`) VALUES
(31, 'Gula Darah Puasa (GDP)', '75', '85', '85', '125', '115', '125', 'Rendah', 'Sedang', 'Tinggi'),
(32, 'Gula Darah 2 Jam PP(GDPP)', '90', '100', '100', '130', '120', '130', 'Rendah', 'Sedang', 'Tinggi'),
(33, 'Hab1c', '3', '4', '4', '9', '8', '9', 'Rendah', 'Sedang', 'Tinggi');

-- --------------------------------------------------------

--
-- Table structure for table `var_output`
--

CREATE TABLE IF NOT EXISTS `var_output` (
  `nilai1` varchar(10) NOT NULL,
  `nilai11` varchar(10) NOT NULL,
  `nilai2` varchar(10) NOT NULL,
  `nilai22` varchar(10) NOT NULL,
  `nilai3` varchar(10) DEFAULT NULL,
  `nilai33` varchar(10) DEFAULT NULL,
  `atr1` varchar(30) NOT NULL,
  `atr2` varchar(30) NOT NULL,
  `atr3` varchar(30) DEFAULT NULL,
  `kendali1` text,
  `kendali2` text,
  `kendali3` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `var_output`
--

INSERT INTO `var_output` (`nilai1`, `nilai11`, `nilai2`, `nilai22`, `nilai3`, `nilai33`, `atr1`, `atr2`, `atr3`, `kendali1`, `kendali2`, `kendali3`) VALUES
('1', '10', '10', '20', '20', '30', 'Negatif Diabetes', 'Pradiabetes', 'Positif Diabetes', 'Anda di Nyatakan Negatif (-) Diabetes , Jaga Selalu kesehatan Anda ', 'Pradiabetes : kondisi saat seseorang mengetahui kadar gula darah yang dimiliki lebih tinggi dibandingkan kadar normal, namun tidak bisa dikategorikan diabetes.', 'Anda di Nyatakan Positif (+) Diabetes , Periksakan diri Anda ke dokter, Jaga selalu pola makan yang teratur.  ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
