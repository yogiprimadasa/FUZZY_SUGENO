<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
include_once("function/function_pengguna.php");

$get_var_id_pengguna = $_GET['id'];
$pengguna = select_pengguna_by_id_pengguna($get_var_id_pengguna);


$current_id_pengguna = $pengguna[0][0];
$current_nama = $pengguna[0][1];
$current_email = $pengguna[0][2];
$current_username = $pengguna[0][3];
$current_password = $pengguna[0][4];
$current_jenis_kelamin = $pengguna[0][5];
$current_alamat = $pengguna[0][6];
$current_hak_akses = $pengguna[0][7];

?>
<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><? echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Edit Pengguna </strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form name="form1" method="post" action="pengguna_edit_submit.php?id=<?php echo $get_var_id_pengguna; ?>">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="BorderBox_ColorStandard">
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td width="3%" class="_css_font_default_11_black">&nbsp;</td>
              <td width="21%" class="_css_font_default_11_black"><strong>NAMA</strong></td>
              <td width="1%" class="_css_font_default_11_black"><strong>:</strong></td>
              <td width="75%"><input name="var_nama" type="text" class="_css_input_text" id="var_nama" value="<?php echo $current_nama; ?>" size="50"></td>
            </tr>
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black"><strong>EMAIL</strong></td>
              <td class="_css_font_default_11_black"><strong>:</strong></td>
              <td><input name="var_email" type="text" class="_css_input_text" id="var_email" value="<?php echo $current_email; ?>" size="50"></td>
            </tr>
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black"><strong>USERNAME</strong></td>
              <td class="_css_font_default_11_black"><strong>:</strong></td>
              <td><input name="var_username" type="text" class="_css_input_text" id="textfield3" value="<?php echo $current_username; ?>" size="50"></td>
            </tr>
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black"><strong>PASSWORD</strong></td>
              <td class="_css_font_default_11_black"><strong>:</strong></td>
              <td><input name="var_password" type="text" class="_css_input_text" id="textfield4" value="<?php echo $current_password; ?>" size="50"></td>
            </tr>
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black"><strong>JENIS KELAMIN</strong></td>
              <td class="_css_font_default_11_black"><strong>:</strong></td>
              <td><select name="var_jenis_kelamin" class="_css_input_text" id="var_jenis_kelamin">
                <option value="LAKI-LAKI" selected>LAKI-LAKI</option>
                <option value="PEREMPUAN">PEREMPUAN</option>
              </select></td>
            </tr>
            <tr>
              <td align="left" valign="top" class="_css_font_default_11_black">&nbsp;</td>
              <td align="left" valign="top" class="_css_font_default_11_black"><strong>ALAMAT</strong></td>
              <td align="center" valign="top" class="_css_font_default_11_black"><strong>:</strong></td>
              <td><textarea name="var_alamat" cols="45" rows="5" class="_css_input_text" id="var_alamat"><?php echo $current_alamat; ?></textarea></td>
            </tr>
            <tr>
              <td class="_css_font_default_11_black">&nbsp;</td>
              <td class="_css_font_default_11_black"><strong>HAK AKSES</strong></td>
              <td class="_css_font_default_11_black"><strong>:</strong></td>
              <td><select name="var_hak_akses" class="_css_input_text" id="var_hak_akses">
                <option value="ADMIN">ADMIN</option>
                <option value="USER">USER</option>
              </select></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><p>
                <input name="button" type="submit" class="button_default_aw" id="button" value="Edit">
                <input name="button" type="button" class="button_default_aw" id="batal" value="Batal" onClick=self.history.back()> 
              </p></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </table>
        </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th height="19" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left" class="_css_font_default_11_b">
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
 
</table>
<p>&nbsp;</p>
</body>
</html>


