<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
include_once("lib/inc.kodeauto.php");
?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
 <script type="text/javascript">
var htmlobjek;
$(document).ready(function(){
  $("#then").change(function(){
    var then = $("#then").val();
    $.ajax({
        url: "ambilpenyakit.php",
        data: "then="+then,
        cache: false,
        success: function(msg){
            $("#daerah").val(msg);
        }
		});
    });
});
</script>
 <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
-->
 </style>
 <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
 <style type="text/css">
<!--
.style2 {color: #FF0000}
-->
 </style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><? echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Input Rule ( Aturan )</strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form action="saverule.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
              <table width="890" border="0" align="left" class="_css_font_default_11">
                
                <tr>
                  <td><strong>Aturan (Rule) </strong></td>
                  <td><strong>:</strong></td>
                  <td><span id="sprytextfield1">
                    <input name="idrule" type="text" id="idrule" size="10" />
                  <span class="textfieldRequiredMsg">Aturan Rule Masih Kosong</span></span><span class="style1">                    *</span></td>
                </tr>
                <tr>
                  <td><strong>If</strong></td>
                  <td>&nbsp;</td>
                  <td><span class="style1">* Contoh R1, R2, R3 dst</span></td>
                </tr>
                <?php
					  $aa=mysql_query("select * from variabel order by idvariabel asc "); 
					  while($a=mysql_fetch_array($aa))
					  {
					  ?>
                <tr>
                  <td width="150">&nbsp;</td>
                  <td width="4">&nbsp;</td>
                  <td width="722">&nbsp;</td>
                </tr>
                <tr>
                  <td><?php echo "$a[1]";?></td>
                  <td>:</td>
                  <td><select name="rule[]" id="rule[]">
                      <option value="<?php  ?>">---Pilih---</option>
                       
                      <option value="<?php echo"$a[atr1]"; ?>"><?php echo"$a[atr1]"; ?></option>
                      <option value="<?php echo"$a[atr2]"; ?>"><?php echo"$a[atr2]"; ?></option>
                      <option value="<?php echo"$a[atr3]"; ?>"><?php echo"$a[atr3]"; ?></option>
                     
                    </select>
                      <input name="idvar[]" type="hidden" id="idvar[]" value="<?php echo"$a[0]"; ?>" /></td>
                </tr>
                <?php } ?>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><strong>Then</strong></td>
                  <td>:</td>
                  <td>
                  <?php
				  echo"
                    <select name=then title='Pilih salah satu output' id=then>";
					echo "<option value=>--- Pilih ---</option>";
            $tampil=mysql_query("SELECT * FROM var_output");
			$r=mysql_fetch_array($tampil);
            echo "<option value=$r[atr1]>$r[atr1] </option>";
		  	echo "<option value=$r[atr2]>$r[atr2] </option>";
			echo "<option value=$r[atr3]>$r[atr3] </option>";
			echo "</select>"; ?>
                 </td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" valign="top"><strong>Posisi ( Daerah )</strong></td>
                  <td align="left" valign="top"><strong>:</strong></td>
                  <td><p>
                    <select name="daerah" id="daerah">
                      <option>---Pilih---</option>
                      <option value="1">1 </option>
                      <option value="2">2 </option>
                     <option value="3">3 </option>
                    </select>
                  </p>
                    
                  <p><span class="style1">*</span> Posisi 1 ( Untuk Negatif Diabetes) <br> 
                  * Posisi 2 ( Untuk <span class="style2">Diagnosa</span> Pradiabetes )<br>
                   * Posisi 3 ( Untuk <span class="style2">Diagnosa</span> Positif Diabetes ) </p></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><div align="center">
                      <input type="submit" class="button_default_aw" name="Submit3" value="Simpan" />
                      <input type="reset" class="button_default_aw" name="Submit22" value="Ulangi" />
                      <input type="button" class="button_default_aw" name="Submit32" value="Kembali" onClick="self.history.back()"/>
                  </div></td>
                </tr>
              </table>
            </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" width="100%" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
  
 
</table>
<p>&nbsp;</p>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</body>
</html>


