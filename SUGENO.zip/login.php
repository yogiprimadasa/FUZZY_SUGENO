<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
 
 
<script language="javascript" src="lib/imagesfileclient/js/jquery.js" ></script>
<script language="javascript" src="lib/imagesfileclient/js/jquery.sha256.js" ></script>
<script language="javascript" src="lib/imagesfileclient/js/jquery.validate.js" ></script>
<script type="application/javascript">
  $(document).ready(function(){
    var validator = $("#form_pass_enc").validate({
			rules: {
				username: "required",
				password: "required"
			} 
		});
    
    $("#form_submit").click(function() {
      if($("#form_pass_enc").valid()) {
        // Optionally you can uncomment this to see if encrypted before we leave the page.
        // alert($.sha256($('#password').val()));
        $('#password').val($.sha256($('#password').val()));
        $('#form_pass_enc').submit();
      }
    });
  });
</script>
 

</script>
		<link rel="stylesheet" href="css/serverstyle.css">
		<link rel="stylesheet" href="css/button.css">
        <link rel="shortcut icon" href="images/gold.png" />
<title>.:: Deteksi Penyakit Diabetes Metode Sugeno ::.</title></head>
<body onload="document.getElementById('captcha-form').focus()"  bgcolor="#e9e9e9">
 
<table width="25%" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <tr>
    <th height="112" scope="col"><img src="images/header.png" width="940" height="160" /></th>
  </tr>
  <tr>
    <td height="210"><table width="100%" height="210" border="0" align="center" cellpadding="0" cellspacing="0" >
      <tr>
        <td width="300%" colspan="3"></td>
      </tr>
      <tr>
        <td colspan="3"></td>
      </tr>
      <tr>
        <td height="158" colspan="3" ><table width="100%" border="0" cellpadding="0" cellspacing="0" class="layout-grid">
            <tr>
              <td width="818" height="323" class="normal"><div class="normal">
               <form  method="post" name="form_pass_enca"   action="login_submit.php">
                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                      
                      
                      <tr>
                        <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>
                        <td width="44%" bgcolor="#FFFFFF">&nbsp;</td>
                        <td width="54%" bgcolor="#FFFFFF"><div align="center">
                          <table width="100%" border="0" align="left"  >
                            <tr>
                              <th width="9%"  scope="col">&nbsp;</th>
                              <td width="2%">&nbsp;</td>
                              <td width="89%" class="_css_font_default_11" >&nbsp;</td>
                            </tr>
                            <tr>
                              <th class="_css_font_default_11"  scope="col"><div align="right"><strong>Username</strong></div></th>
                              <th class="_css_font_default_11"  scope="col"><div align="center"><strong>:</strong></div></th>
                              <th scope="col"><div align="left" class="_css_font_default_11" >
                                  <input name="username" type="text" class="_css_input_text" id="username" size="40" />
                              </div></th>
                            </tr>
                            <tr>
                              <th class="_css_font_default_11"  scope="col"><div align="right"><strong>Password</strong></div></th>
                              <th class="_css_font_default_11"  scope="col"><div align="center"><strong>:</strong></div></th>
                              <th scope="col"><div align="left" class="_css_font_default_11" >
                                  <input name="password" type="password" class="_css_input_text" id="password" size="40" />
                              </div></th>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td class="_css_font_default_11" >Pemeriksaan keamanan, masukkan kata di bawah ini : </td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td><img src="lib/captcha/captcha.php" id="captcha" border="1" /><br/>
                                  <!-- CHANGE TEXT LINK -->
                                  <br />
                                  <span class="_css_font_default_11">Tidak dapat membaca kata-kata ?</span> <a href="#" class="_css_font_default_link_11" 
						id="change-image" onclick="
						document.getElementById('captcha').src='lib/captcha/captcha.php?'+Math.random();
						document.getElementById('captcha-form').focus();"><strong> coba rubah kata lain</strong></a><br/>
                                  <input name="captcha" type="text" class="_css_input_text" id="captcha-form" />                              </td>
                            </tr>
                            <tr>
                              <td height="30">&nbsp;</td>
                              <td>&nbsp;</td>
                              <td align="left" valign="middle"><input name="form_submit" type="submit" class="button" id="form_submit" value="Login" /></td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td class="_css_font_default_11" >&nbsp;</td>
                            </tr>
                            <tr>
                              <td>&nbsp;</td>
                              <td>&nbsp;</td>
                              <td class="_css_font_default_11" >Belum punya Account ? Silahkan Mendaftar di <strong><a href="register.php" class="_css_font_default_link_11">Daftar Pengguna Baru</a></strong></td>
                            </tr>
                          </table>
                        </div></td>
                      </tr>
                      <tr>
                        <td colspan="3" align="center" bgcolor="#FFFFFF"><div align="center"><img src="images/line_full.gif" width="100%" /></div></td>
                        </tr>
                    </table>
                    </form>
                  </div></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="35" bgcolor="#FFFFFF"><div align="center" class="_css_font_default_11" >
      <?php include_once("copyright.php"); ?>
    </div></td>
  </tr>
  
</table>
</body>
</html>


