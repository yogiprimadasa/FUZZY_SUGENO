<html>
<head>
 <title>Tree</title>
 <style>
  ul{
  	list-style-type:none; /* setiap list dihilangkan penanda setiap list-nya */
  	padding-left: 12px;
  	margin-left: 12px;
  }
  a:link, a:visited{
  	text-decoration: none;
  	font-size: 14px;
  	color: #006;
  }
  a:hover, a:active{
  	text-decoration: underline;
  }
 </style>
 <script language="javascript" src="jquery.js"></script> 
 <script language="javascript">
  function openTree(id){
  	// ambil semua tag <ul> yang mengandung attribut parent = id dari link yang dipilih
  	var elm = $('ul[@parent='+id+']'); 
  	if(elm != undefined){ // jika element ditemukan
  	  if(elm.css('display') == 'none'){ // jika element dalam keadaan tidak ditampilkan
  	    elm.show(); // tampilkan element 	  	
  	    $('#img'+id).attr('src','folder-1.png'); // ubah gambar menjadi gambar folder sedang terbuka
  	  }else{
  	  	elm.hide(); // sembunyikan element
  	    $('#img'+id).attr('src','folder-3.png'); // ubah gambar menjadi gambar folder sedang tertutup
  	  }
	}
  }
 </script> 
</head>
<body>
 <?
   $root_parent = 1015130801;
    mysql_connect('localhost','root','12345');
 	mysql_select_db('project_daily_activity');
 	
 	// tampilkan menu di sortir berdasar id dan parent_id agar menu ditampilkan dengan rapih
 	//$query = mysql_query('SELECT * FROM internal_link ORDER BY id,parent_id');
	$query = mysql_query('SELECT kode_posisi AS id, SUBSTR( kode_posisi, 1, LENGTH( kode_posisi ) -2 ) AS parent_id, nama
								FROM  `master_user` 
								ORDER BY kode_posisi, SUBSTR( kode_posisi, 1, LENGTH( kode_posisi ) -2 )'); 
 	$data = array();
 	while($row = mysql_fetch_object($query)){
 	  $data[$row->parent_id][] = $row; // simpan data dari databae ke dalam variable array 3 dimensi di PHP
	}
	
	echo loop($data,$root_parent, $root_parent); // lakukan looping menu utama
	
	/* fungsi ini akan terus di looping secara rekursif agar dapat menampilkan menu dengan format tree (pohon)
     * dengan kedalaman jenjang yang tidak terbatas */
 	function loop($data,$parent, $asd){ 
	//echo $asd."<br/>";
 	  if(isset($data[$parent])){ // jika ada anak dari menu maka tampilkan
 	    /* setiap menu ditampilkan dengan tag <ul> dan apabila nilai $parent bukan 0 maka sembunyikan element 
 	     * karena bukan merupakan menu utama melainkan sub menu */
 	  	$str = '<ul parent="'.$parent.'" style="display:'.($parent>$asd ?'none':'').'">'; 
 	  	foreach($data[$parent] as $value){
 	  	  /* variable $child akan bernilai sebuah string apabila ada sub menu dari masing-masing menu utama
 	  	   * dan akan bernilai negatif apabila tidak ada sub menu */
 	  	  $child = loop($data,$value->id, $asd); 
 	  	  $str .= '<li>';
 	  	  /* beri tanda sebuah folder dengan warna yang mencolok apabila terdapat sub menu di bawah menu utama 	  	   
 	  	   * dan beri juga event javascript untuk membuka sub menu di dalamnya */
 	  	  $str .= ($child) ? '<a href="javascript:openTree('.$value->id.')"><img src="folder-3.png" id="img'.$value->id.'" border="0" width="20" height="20"></a>' : '<img src="folder-1.png" border="0" width="20" height="20">';
 	  	  $str .= '<a href="'.$value->id.'" target="_blank">&nbsp;&nbsp;'.$value->nama.'</a></li>';
 	  	  if($child) $str .= $child;
		}
		$str .= '</ul>';
		return $str;
	  }else return false;	  
	}
 	
 ?>
</body>
</html>
