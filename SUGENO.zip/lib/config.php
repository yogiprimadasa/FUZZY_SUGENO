<?php
	/* File Konfigurasi Database Mysql */
	$mysql_host			= "localhost";
	$mysql_user			= "root";
	$mysql_password			= "";
	$mysql_database			= "dbfuzzysugeno";
	$koneksi	= mysql_connect($mysql_host, 
							$mysql_user, 
							$mysql_password,$mysql_database);
	mysql_connect($mysql_host,$mysql_user,$mysql_password);
	mysql_select_db($mysql_database);
	error_reporting(0);
?>
