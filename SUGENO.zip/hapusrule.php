<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
////////////////////
mysql_query("delete from rule where idrule='$_GET[id]'");
mysql_query("delete from tmp_rule where idrule='$_GET[id]'");
/////////////////////////

 header("location:rule.php");
?>
