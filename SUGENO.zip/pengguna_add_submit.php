<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
include_once("function/function_pengguna.php");
$get_var_id_pengguna = $_POST['var_id_pengguna'];
$get_var_nama = $_POST['var_nama'];
$get_var_email = $_POST['var_email'];
$get_var_username = $_POST['var_username'];
$get_var_password = $_POST['var_password'];
$get_var_jenis_kelamin = $_POST['var_jenis_kelamin'];
$get_var_alamat = $_POST['var_alamat'];
$get_var_hak_akses = $_POST['var_hak_akses'];

if (($get_var_nama=="") && ($get_var_email=="") && ($get_var_username=="") && ($get_var_password=="") && ($get_var_alamat=="")) {
	echo '<script language="javascript">alert("Data pengguna Gagal Disimpan, tidak boleh kosong !")</script>';
	echo '<script language="javascript">window.location = "pengguna_add.php"</script>';
	
} else {
	
$return_insert_pengguna = insert_pengguna($get_var_nama,$get_var_email,$get_var_username,$get_var_password,$get_var_jenis_kelamin,$get_var_alamat,$get_var_hak_akses);
if ($return_insert_pengguna==1) {
	echo '<script language="javascript">alert("Data pengguna Berhasil Disimpan !")</script>';
	echo '<script language="javascript">window.location = "pengguna.php"</script>';
} 
}
?>
