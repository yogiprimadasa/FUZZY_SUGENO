<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
<style type="text/css">
<!--
.style2 {color: #FFFFFF; font-weight: bold; }
.style4 {font-weight: bold}
-->
</style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Edit Relasi </strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form action="saverule1.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
              <table width="890" border="0" align="left" class="_css_font_default_11">
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <?php
		  $q=mysql_fetch_array(mysql_query("select * from rule where idrule='$_GET[id]'"));
		  ?>
                <tr>
                  <td width="131"><strong>Aturan (Rule) </strong></td>
                  <td width="27"><strong>:</strong></td>
                  <td width="301"><input name="idrule" type="text" id="idrule" size="10" value="<?php echo"$q[0]";?>" readonly="readonly"/></td>
                </tr>
                <tr>
                  <td><strong>If</strong></td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><table width="100%" border="0" align="center">
                      <?php
					  $a=mysql_query("select * from tmp_rule where idrule='$_GET[id]' order by idvariabel asc");
					  $no=1;
					  while($ba=mysql_fetch_array($a))
					  {
						  $b=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$ba[idvariabel]'"));
					  ?>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="129"><?php echo"$b[1]"; ?><strong>
                          <input name="idvar[]" type="hidden" id="idvar[]" value="<?php echo"$ba[idvariabel]"; ?>" />
                          <input name="idrule1[]" type="hidden" id="idrule1[]" value="<?php echo"$_GET[id]"; ?>" />
                        </strong></td>
                        <td width="24">:</td>
                        <td width="300"><select name="rule1[]" id="rule1[]">
                            <option selected="selected" value="<?php echo"$ba[rule1]"; ?>"><?php echo"$ba[rule1]"; ?></option>
                            <option value="<?php echo"$b[atr1]"; ?>"><?php echo"$b[atr1]"; ?></option>
                            <option value="<?php echo"$b[atr2]"; ?>"><?php echo"$b[atr2]"; ?></option>
                            <option value="<?php echo"$b[atr3]"; ?>"><?php echo"$b[atr3]"; ?></option>
                        </select></td>
                      </tr>
                      <?php
					  }
					  ?>
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><strong>Then</strong></td>
                  <td>:</td>
                  <td><input name="then" type="text" id="then" size="30" value="<?php echo"$q[maka]"; ?>" /></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Daerah</td>
                  <td>:</td>
                  <td><select name="daerah" id="daerah">
                      <option value="<?php echo"$q[daerah]"; ?>"><?php echo"$q[daerah]"; ?></option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                     
                  </select></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><div align="center">
                      <input type="submit" class="button_default_aw" name="Submit3" value="Simpan" />
                      <input type="reset" class="button_default_aw" name="Submit22" value="Ulangi" />
                      <input type="button" class="button_default_aw" name="Submit32" value="Kembali" onClick="self.history.back()"/>
                  </div></td>
                </tr>
              </table>
            </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
  
 
</table>
<p>&nbsp;</p>
</body>
</html>


