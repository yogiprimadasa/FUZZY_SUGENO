<?php
// session_start();
if($_SESSION['id_user'] == '') {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
?><title>.:: Deteksi Penyakit Diabetes Metode Sugeno ::.</title>
<div id="ddtopmenubar" class="mattblackmenu">
	<ul>
		 <li><a href="home.php">Home</a></li>
		 	
		 <?php 
		 if ($_SESSION['kode_user']=="ADMIN") {
		 ?>
		 <li><a href="#" rel="submenu_datamaster" >Input</a></li>
          <li><a href="#" rel="submenu_datamaster1" >Proses</a></li>
          
		 <?php
		 }
		 ?>
         <?php if ($_SESSION['kode_user']=="USER"){ 
		 ?>
          <li><a href="reg.php">Konsultasi</a></li>
           <li><a href="history.php">History Diagnosa</a></li>
		 
		<?php } ?>
		 
		  <li><a href="penulis.php">About me</a></li>
		 <li><a href="logout.php">&nbsp;&nbsp;Logout&nbsp;&nbsp;</a></li>
	</ul>
</div>

<script type="text/javascript">
	ddlevelsmenu.setup("ddtopmenubar", "topbar") 
</script>

<ul id="submenu_datamaster" class="ddsubmenustyle">

    <li><a href="var.php">1.1 Input Variabel </a></li>
	  
	<li><a href="varout.php">1.2 Input Variabel Output</a></li>  
    <li><a href="rule.php">1.3 Input Data Relasi</a></li>  
</ul>
<ul id="submenu_datamaster1" class="ddsubmenustyle">
	<li><a href="pengguna.php">2.1 Data User</a></li>
	   
	<li><a href="daftar.php">2.2 Hasil Diagnosa</a></li>  
</ul>

 
 
 

 

