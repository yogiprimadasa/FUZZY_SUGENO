<p>Diagnosa Penyakit Diabetes Metode Fuzzy Sugeno </p>
<p>Copyright &copy; 2014 All Rights Reserved.</p>
