<?php
	session_start();
	include_once("lib/config.php");
	include_once("function/function_pengguna.php");
	include_once("function/function_others.php");
	
	$get_session_capcay = $_SESSION['captcha'];
	//echo "get_session_capcay= ".$get_session_capcay."<BR>";
	$request_captcha = htmlspecialchars($_REQUEST['captcha']);
	//echo "request_captcha= ".$request_captcha;

	if ($get_session_capcay!=$request_captcha) {
		echo '<script language="javascript">alert("ERROR : Login Gagal, Captcha yang Anda masukkan salah. Silahkan ulangi kembali.")</script>';
		echo '<script language="javascript">window.location = "login.php"</script>';			
	} else
	{
	
		
		$get_var_username = mysql_real_escape_string(stripslashes(trim($_POST['username'])));
		//echo $get_var_username; echo "<BR>";		
		$get_var_password = mysql_real_escape_string(stripslashes(trim($_POST['password'])));
		//echo $get_var_password; echo "<BR>";	
		$user = login($get_var_username,$get_var_password);
		//print_r($temporary_file);	
		
		$current_id_user = $user[0][0];
		
		if ($current_id_user=="") {
			echo '<script language="javascript">alert("Login Gagal ! User tidak ditemukan. Silahkan ulangi kembali.")</script>';
			echo '<script language="javascript">window.location = "login.php"</script>';			
		} else {
		
					$current_id_user = $user[0][0];
					$current_nama_lengkap = $user[0][1];
					$current_email = $user[0][2];

					
					$current_username = $user[0][3];
					$current_password = $user[0][4];
					$current_jenis_kelamin = $user[0][5];
					$current_alamat = $user[0][6];

					$current_kode = $user[0][7];
					
 
		

					$_SESSION['id_user'] = $current_id_user;
					$_SESSION['kode_user'] = $current_kode;
					$_SESSION['nama'] = $current_nama_lengkap;
					$_SESSION['username'] = $current_username;
					$_SESSION['email'] = $current_email;
					$_SESSION['jenis_kelamin'] = $current_jenis_kelamin;
					$_SESSION['alamat'] = $current_alamat;


					echo '<script language="javascript">window.location = "home.php"</script>';
		}	

	}				


?>