<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
include_once("function/function_pengguna.php");
$get_id_pengguna = $_GET['id'];
$return_delete_pengguna = delete_pengguna_by_id_pengguna($get_id_pengguna);
if ($return_delete_pengguna==1) {
echo '<script language="javascript">alert("Data pengguna Berhasil di Hapus !")</script>';
echo '<script language="javascript">window.location = "pengguna.php"</script>';
} else {
echo '<script language="javascript">alert("Data pengguna Gagal di Hapus !")</script>';
echo '<script language="javascript">window.location = "pengguna.php"</script>';
} 
?>
