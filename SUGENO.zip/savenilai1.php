<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
include"lib/config.php";

$a=mysql_query("select * from variabel order by idvariabel asc");
while($b=mysql_fetch_array($a))
{
 $nilai=mysql_fetch_array(mysql_query("select * from nilai where idpasien='$_GET[id]' and idvariabel='$b[idvariabel]'"));
 $x=$nilai[nilai];
 
 if(empty($b[atr3]))
 {
  
  // if nilai dibawah 40 maka fuzzy=1
  // if nilai diatas 60 maka fuzzy=1
  // if nilai antara 40 sampai 60 maka fuzzy:
  $nilaiturun1=round(($b[nilai11]-$x)/($b[nilai11]-$b[nilai2]),6);
  $nilainaik1=round(($x-$b[nilai2])/($b[nilai11]-$b[nilai2]),6);
 }
 else
 {
 
  // if nilai dibawah 35 maka fuzzy=1
  // if nilai antara 35 sampai 50 maka fuzzy:
  $nilaiturun1=round(($b[nilai11]-$x)/($b[nilai11]-$b[nilai2]),6);
  $nilainaik1=round(($x-$b[nilai2])/($b[nilai11]-$b[nilai2]),6);
  //----------->
  // if nilai diatas 65 maka fuzzy=1
  // if nilai antara 50 sampai 65 maka fuzzy:
  $nilaiturun2=round(($b[nilai22]-$x)/($b[nilai22]-$b[nilai3]),6);
  $nilainaik2=round(($x-$b[nilai3])/($b[nilai22]-$b[nilai3]),6);
 }
 
 
 
//////////////fungsi if untuk menentukan nilai fuzzy//////////////////////////////////
if(empty($b[atr3]))// 2 himpunan fuzzy
{
  // 0 - 40 ( rendah) var Kondisi anak
  if($x<=$b[nilai2])
  {
   $predikat1=$b[atr1];
   $nilai1=1;
   $nilai2=0;
   $nilai3=0;
  }
  // 40> X <=60 (normal/rewel)
  elseif($x>$b[nilai2] and $x<$b[nilai11])
  {
   $nilai1=$nilaiturun1;
   $nilai2=$nilainaik1;
   $nilai3=0;
   if($nilaiturun1<=$nilainaik1)
   {
    $predikat1=$b[atr1];
   }
   else
   {
    $predikat1=$b[atr2];
   }
  }
  //  X <=60 (rewel)
  else
  {
   $nilai1=0;
   $nilai2=1;
   $nilai3=0;
   $predikat1=$b[atr2];
  } 
}
else // 3 himpunan fuzzy var pembengkakan kelenjar getah bening
{
  // 0 - 35 (normal) 
  if($x<=$b[nilai2])
  {
   $predikat1=$b[atr1];
   $nilai1=1;
   $nilai2=0;
   $nilai3=0;
  }
  // 35> X <50 (normal/kecil)
  elseif($x>$b[nilai2] and $x<$b[nilai11])
  {
   $nilai1=$nilaiturun1;
   $nilai2=$nilainaik1;
   $nilai3=0;
   if($nilaiturun1<=$nilainaik1)
   {
    $predikat1=$b[atr1];
   }
   else
   {
    $predikat1=$b[atr2];
   }
  }
  // X =50 (kecil)
  elseif($x==$b[nilai11])
  {
   $nilai1=0;
   $nilai2=1;
   $nilai3=0;
   $predikat1=$b[atr2];
  }
  // 50=> X <65 (kecil/besar)
  elseif($x>$b[nilai11] and $x<$b[nilai22])
  {
   $nilai1=0;
   $nilai2=$nilaiturun2;
   $nilai3=$nilainaik2;
   if($nilai2==0)
   {
    $predikat1=$b[atr2];
   }
   elseif($nilai2<=$nilai3)
   {
    $predikat1=$b[atr2];
   }
   else
   {
    $predikat1=$b[atr3];
   }
  }
  //  X <=65 (besar)
  else
  {
   $nilai1=0;
   $nilai2=0;
   $nilai3=1;
   $predikat1=$b[atr3];
  }
}

 ////////skrip input nilai fuzzy variabel ke dalam tabel nilai////////////////////////////////////////
mysql_query("update nilai set predikat='$predikat1',nilai1='$nilai1',nilai2='$nilai2',nilai3='$nilai3'
where idpasien='$_GET[id]' and idvariabel='$b[0]'  ");
//////----------------------------------------------------------------------------
}
if ($_SESSION['kode_user']=="ADMIN") {
header("location:hasil.php?id=$_GET[id]");
}
else{
header("location:hasil1.php?id=$_GET[id]");
}?>