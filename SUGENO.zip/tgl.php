<?php
$english_day = date("l");
switch($english_day)
{
case "Monday":
$indonesia_day = "Senin";
break;
case "Tuesday":
$indonesia_day = "Selasa";
break;
case "Wednesday":
$indonesia_day = "Rabu";
break;
case "Thursday":
$indonesia_day = "Kamis";
break;
case "Friday":
$indonesia_day = "Jum'at";
break;
case "Saturday":
$indonesia_day = "Sabtu";
break;
default:
$indonesia_day = "Minggu";
}
echo "<center>";
echo "<font color= yellow>";

echo("$indonesia_day");

echo ",";

 
echo (date("j"));
$a=date("m");
$c=date("Y");
if ($a==01)
{
$b=" Januari";
}
if ($a==02)
{
$b=" Februari";
}
if ($a==03)
{
$b=" Maret";
}
if ($a==04)
{
$b=" April";
}
if ($a==05)
{
$b=" Mei";
}
if ($a==06)
{
$b=" Juni";
}
if ($a==07)
{
$b=" Juli";
}
if ($a==08)
{
$b=" Agustus";
}
if ($a==09)
{
$b=" September";
}
if ($a==10)
{
$b=" Oktober";
}
if ($a==11)
{
$b=" November";
}
if ($a==12)
{
$b=" Desember";
}

echo " $b $c"; 
echo "</font>";
echo "</center>";
$month=date("m");
$year=date("Y");
$day=date("d");
$endDate=date("t",mktime(0,0,0,$month,$day,$year));
echo '<style>td {
font-size:11;
font-family:verdana;
}
</style>
';
echo '<table align="center" border="0" width="195" cellpadding=2 cellspacing=1 style=""><tr><td align=center>';
echo '</td></tr></table>';
echo '<table align="center" border="0" width="195" cellpadding=2 cellspacing=1>
<tr>
<td align=center><font color=red>Mg</font></td>
<td align=center><font color=yellow>Sn</td>
<td align=center><font color=yellow>Sl</td>
<td align=center><font color=yellow>Rb</td>
<td align=center><font color=yellow>Km</td>
<td align=center><font color=yellow>Ju</td>
</font>
<td align=center><font color=yellow>Sb</font></td>
</tr>
';
/*
mengecek tanggal 1 bulan sekarang ada pada hari ke berapa
kemudian tambahkan cell td sebanyak var $s
*/
$s=date ("w", mktime (0,0,0,$month,1,$year));
for ($ds=1;$ds<=$s;$ds++) {
echo "<td style=\"font-family:arial;color:white\" width=\"15%\"
align=center valign=middle bgcolor=\"\">
</td>";
}
for ($d=1;$d<=$endDate;$d++) {
if (date("w",mktime (0,0,0,$month,$d,$year)) == 0) { echo "<tr>"; }
//default warna huruf
$fontColor="Brown";
//
if (date("D",mktime (0,0,0,$month,$d,$year)) == "Sun")
{ $fontColor="red"; }
//
if (date("D",mktime (0,0,0,$month,$d,$year)) == "Sat")
{ $fontColor="Green"; }
//menulis tanggal
echo "<td style=\"font-family:arial;color:white\" width=\"15%\"
align=center valign=middle> <span
style=\"color:$fontColor\">$d</span></td>";
//jika tanggal adalah hari sabtu (6) akhiri baris </tr>
if (date("w",mktime (0,0,0,$month,$d,$year)) == 6) { echo "</tr>"; }
}
//akhir table
echo '</table>';
?>