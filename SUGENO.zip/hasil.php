<?php

session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
<style type="text/css">
<!--
.style7 {color: #FFFFFF; font-weight: bold; }
.style8 {
	font-size: 14px;
	font-weight: bold;
}
.style10 {color: #FFFFFF; font-weight: bold; font-size: 14px; }
.style11 {font-size: 14px}
.style12 {
	font-weight: bold;
	color: #0000FF;
}
-->
</style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="940" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Hasil Diagnosa Penyakit Diabetes</strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form action="savenilai.php?id=<?php echo"$_GET[id]"; ?>" method="post" enctype="multipart/form-data" name="form1" id="form1">
              <table width="890" border="0" align="left" class="_css_font_default_11">
                <?php
			  $a=mysql_fetch_array(mysql_query("select * from user where idpasien='$_GET[id]'"));
			  ?>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td>Nama</td>
                  <td>:</td>
                  <td><?php echo"$a[1]"; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Alamat</td>
                  <td>:</td>
                  <td><?php echo"$a[2]"; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>:</td>
                  <td><?php echo"$a[3]"; ?></td>
                </tr>
                <tr>
                  <td width="94">&nbsp;</td>
                  <td width="17">&nbsp;</td>
                  <td width="766">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><hr /></td>
                </tr>
                <tr>
                  <td colspan="3"><table width="885" border="0" align="left" class="_css_font_default_11">
                    <?php
					  echo "<h3>Hasil Nilai Yang Anda Inputkan</h3>";
					  $a=mysql_query("select * from variabel order by idvariabel asc ");
					  while($b=mysql_fetch_array($a))
					  {
					   $c=mysql_fetch_array(mysql_query("select * from nilai where idpasien='$_GET[id]' and idvariabel='$b[0]'"));
					  ?>
                    <tr bgcolor="#333333">
                      <td width="786"><span class="style10"><?php echo"$b[1]";  ?></span></td>
                    </tr>
                    <tr>
                      <td><span class="style8">
                        <?php 
				  echo"$c[nilai]"; echo" ($c[predikat]) ";
				  if(empty($b[atr3]))
				  {
				   echo" ($c[nilai1] ; $c[nilai2]) ";
				  }
				  else
				  {
				   echo" ($c[nilai1] ; $c[nilai2] ; $c[nilai3]) ";
				  }?>
                      </span></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>
                    <?php } ?>
                  </table></td>
                </tr>
                <tr>
                  <td colspan="3"><h2><strong>Detail Nilai Bisa di Lihat di Tabel Rule ini :</strong></h2></td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><table width="100%" border="0">
                    <tr>
                      <td colspan="3"><table width="100%" border="1" align="left" class="_css_font_default_11">
                        <tr bgcolor="#333333">
                          <td width="104"><div align="center" class="style7">Nama Rule</div></td>
                          <td width="765"><div align="center" class="style7"> Aturan (Rule) </div></td>
                        </tr>
                        <?php
						
						// Mengecek rule dari databasenya 
						
						echo "<h3> Hitung Z sebagai berikut </h3>";
					  	
						echo "Nilai Min x Nilai z :";
					  $a=mysql_query("select * from rule ");
					  
					  while($b=mysql_fetch_array($a))
					  
					  {
					  //echo $b[min];
					  //echo "$z";
					  
					  echo "$pred x $z";
					  
					  /////////////////////////////////////////////////////////////////////////////////////////////////////////
 ?>
                        <tr>
                          <td><div align="center" class="style11"><?php echo"$b[0]"; ?></div></td>
                          <td><span class="style11">
                            <?php
              $z=mysql_num_rows(mysql_query("select * from tmp_rule where idrule='$b[0]'"));	
			  $c=mysql_query("select * from tmp_rule where idrule='$b[0]' order by idvariabel asc");			  
			  $i=1;
			  while($d=mysql_fetch_array($c))
			  {
		        $e=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$d[idvariabel]'"));
				if($i==$z)
				{
				 echo"$e[variabel] <font color=red><b>$d[rule1]</b></font> ";echo" Then <font color=brown><strong>$b[maka]</strong></font>";
				}
				else
				{
				 echo"$e[variabel] <font color=red><b>$d[rule1]</b></font> <font color=black>And</font> ";
				}
				$i++;
			  }
				
              ?>
                          </span></td>
                        </tr>
                        <tr>
                          <td colspan="2"><table width="100%" border="1" align="left" cellpadding="0" cellspacing="0" class="_css_font_default_11">
                              <tr>
                                <?php
                  $c=mysql_query("select * from tmp_rule where idrule='$b[0]' order by idvariabel asc");			  
			  while($d=mysql_fetch_array($c)) 
			  {
				  $var=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$d[idvariabel]'"));
				   ?>
                                <td width="282"><div align="center"><?php echo"$var[variabel]<br>($d[rule1])"; ?></div></td>
                                <?php
					  } 
					  ?>
                                <td width="90"><div align="center" class="style12">
                                  <h3> Nilai Min (&alpha;) </h3>
                                </div></td>
                                <td width="62"><div align="center" class="style12">
                                  <h3>Nilai (z) </h3>
                                </div></td>
                                <td width="62"><div align="center" class="style12">
                                  <h3>(&alpha; x z) </h3>
                                </div></td>
                              </tr>
                              <tr>
                                <?php
                  $c=mysql_query("select * from tmp_rule where idrule='$b[0]' order by idvariabel asc");			  
			  while($d=mysql_fetch_array($c)) 
			  {
				  
$var=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$d[idvariabel]'"));
$t12=mysql_fetch_array(mysql_query("select * from nilai where idpasien='$_GET[id]' and  idvariabel='$d[idvariabel]' "));
    if($d[rule1]==$var[atr1]) { 
	$t13=$t12[nilai1]; 
	} 
	
	elseif($d[rule1]==$var[atr2]) { 
	$t13=$t12[nilai2]; 
	} 
	
	else  { 
	$t13=$t12[nilai3]; 
	} 
				  
mysql_query("insert into min values ('$_GET[id]','$b[0]','$t13')");
				  
				   ?>
                                <td width="282"><div align="center"><?php echo"$t13"; ?></div></td>
                                <?php
					  } 

$min=mysql_fetch_array(mysql_query("select * from min where idpasien='$_GET[id]' and idrule='$b[idrule]' order by min asc"));

$tmin=mysql_num_rows(mysql_query("select * from tmp_min where idpasien='$_GET[id]' and idrule='$b[0]'"));

if($tmin==0) { mysql_query("insert into tmp_min values ('$_GET[id]','$b[0]','$min[min]')"); } 
else { mysql_query("update tmp_min set min='$min[min]' where idpasien='$_GET[id]' and idrule='$b[0]' "); }

mysql_query("delete from min where idpasien='$_GET[id]' and idrule='$b[0]'");
			   ?>
                                <td><div align="center" class="style12">
                                    <h3><?php echo $min[min];?>                                        </h3>
                                </div></td>
                                
								
								<?php

// Menampilkan hasil nilai Z dari database 

$oke=mysql_fetch_array(mysql_query("select * from var_output"));
if($b[daerah]==1)
{
 $z=$oke[nilai11];
}
elseif($b[daerah]==2)
{
$z=$oke[nilai22];
 
}
elseif($b[daerah]==3)
{
 $z=$oke[nilai33];

}
							  ?>
                                <td><div align="center" class="style12">
                                    <h3><?php echo $z;?>                                        </h3>
                                </div></td>
                                <?php
$pred=$z*$min[min];
?>
                                <td><div align="center" class="style12">
                                    <h3><?php echo $pred;?>                                        </h3>
                                </div></td>
                              </tr>
                            </table>
                              <br /></td>
                        </tr>
                        <?php
						
$alpa+=$min[min];	
$pr+=$pred;

//echo "<br>";
//echo "$pred";


}
?>
                      </table></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" align="center"><?php


// Rumus menentukan hasil perhitungan 
$defuzzy=$pr/$alpa;

$def=mysql_num_rows(mysql_query("select * from defuzzy where idpasien='$_GET[id]'"));
if($def==0) { mysql_query("insert into defuzzy values ('$_GET[id]','$defuzzy')"); }
else { mysql_query("update defuzzy set defuzzy='$defuzzy' where idpasien='$_GET[id]'"); }

$def1=mysql_fetch_array(mysql_query("select * from defuzzy where idpasien='$_GET[id]'"));
$defuzzy=$def1[defuzzy];

$solusi=mysql_fetch_array(mysql_query("select * from var_output "));
// 0-20
if($defuzzy>1 and $defuzzy<=10 )
{
 $naik=0;
 $turun=1;
 $solusi1=$solusi[atr1];
 $kendali=$solusi[kendali1];
}
// 20-30
elseif($defuzzy>10 and $defuzzy<=20)
{
 $naik=($defuzzy-$solusi[nilai2])/($solusi[nilai11]-$solusi[nilai2]);
 $turun=($solusi[nilai11]-$defuzzy)/($solusi[nilai11]-$solusi[nilai2]);
 if($naik<=$turun)
 {
  $solusi1=$solusi[atr1];
  $kendali=$solusi[kendali1];
 }
 else
 {
  $solusi1=$solusi[atr2];
  $kendali=$solusi[kendali2];
 }
}
// 30-50
elseif($defuzzy>20 and  $defuzzy<=30)
{
 $naik=($defuzzy-$solusi[nilai11])/($solusi[nilai22]-$solusi[nilai11]);
 $turun=($solusi[nilai22]-$defuzzy)/($solusi[nilai22]-$solusi[nilai11]);
 if($naik<=$turun)
 {
  $solusi1=$solusi[atr2];
  $kendali=$solusi[kendali2];
 }
 else
 {
  $solusi1=$solusi[atr3];
  $kendali=$solusi[kendali3];
 }
}
/////////////////////////////////
// Hasil proses perhitungan sugeno 

//echo "$alpa <br/>";
echo "<h3>Hasil Perhitungan Sugeno</h3>";

 
echo"Defuzzy atau Nilai Z = $pr/$alpa=$defuzzy<br /><br />";

echo"Hasil Diagnosa Penyakit Diabetes : <strong>$solusi1</strong><br />";
echo"Pencegahan Penyakit Diabetes Dapat di Lakukan : <strong>$kendali</strong><br />";




?></td>
                    </tr>
                    <tr>
                      <td colspan="3">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" align="center"> <a href="home.php" class="button_default_aw">Home</a></td>
                    </tr>
                    <tr>
                      <td colspan="3"><hr size="5" color="#FF0000" /></td>
                    </tr>
                  </table></td>
                </tr>
              </table>
            </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" width="100%" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
  
  <tr>
    <td height="22" colspan="3" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>


