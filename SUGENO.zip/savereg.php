<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
include"lib/config.php";


$idvar=$_POST[idvar];
$q=count($idvar);
$i=0;
while ($i<$q) 
{
 $nilai=$_POST[nilai];
 if(empty($nilai[$i])) { 
 echo '<script language="javascript">alert("Nilai Gejala Masih Kosong !")</script>';
 echo '<script language="javascript">window.location = "reg.php"</script>';
 $t=1; 
 
 }
 
 elseif(!is_numeric($nilai[$i])) { 
 $t=1; 
 } 
 else { $t==0; }
 $i++;
}
	
	
 $idvar=$_POST[idvar];
 $q=count($idvar);
 $i=0;
 $z=0;
 while ($i<$q) 
 {
  $idvar=$_POST[idvar];
  $nilai=$_POST[nilai];
  $oke=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$idvar[$i]'"));
  
  
  if($nilai[$i]>$oke[nilai33] )
  {
   $z=$z+1;
  }
 
  else
  {
   $z=$z+0;
  }
  $i++;
 }
 
 if($z >1) 
 {
 echo '<script language="javascript">alert("Harap isi dengan Benar Nilai Gejala !")</script>';
	echo '<script language="javascript">window.location = "reg.php"</script>';	
     
 }
 else
 {
	
	
	
	
mysql_query("insert into user values ('','$_POST[a]','$_POST[b]','$_POST[c]')");
$petani=mysql_fetch_array(mysql_query("select * from user order by idpasien desc"));


$idvar=$_POST[idvar];
$q=count($idvar);
$i=0;
 while ($i<$q) 
 {
  $idvar=$_POST[idvar];
 // $idvisitor=$_POST[idvisitor];
  $nilai=$_POST[nilai];
  if(empty($nilai)){
  echo '<script language="javascript">alert("Nilai Gejala Masih Kosong !")</script>';
 echo '<script language="javascript">window.location = "reg.php"</script>';
  }
  else {
  
  
  mysql_query("insert into nilai values('[$i]','$petani[0]','$idvar[$i]','$nilai[$i]','','','','')"); 
  $i++;
 }
 }
 header("location:savereg1.php?id=$petani[0]");
 
 }
 
//}
?>