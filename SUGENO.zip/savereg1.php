<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
include_once("lib/config.php");


$a=mysql_query("select * from variabel order by idvariabel asc");
while($b=mysql_fetch_array($a))
{
 $nilai=mysql_fetch_array(mysql_query("select * from nilai where idpasien='$_GET[id]' and idvariabel='$b[idvariabel]'"));
 $x=$nilai[nilai];
 
  $nilaiturun1=round(($b[nilai11]-$x)/($b[nilai11]-$b[nilai2]),6);
  $nilainaik1=round(($x-$b[nilai2])/($b[nilai11]-$b[nilai2]),6);
  $nilaiturun2=round(($b[nilai22]-$x)/($b[nilai22]-$b[nilai3]),6);
  $nilainaik2=round(($x-$b[nilai3])/($b[nilai22]-$b[nilai3]),6);


/*echo $nilainaik1;
echo $nilainaik2;
echo $nilaiturun1;
echo $nilaiturun2;
*/



// Kondisi 1
if(empty($b[atr3]))
{
  if($x<=$b[nilai11])
  {
   $predikat1=$b[atr1];
   $nilai1=1;
   $nilai2=0;
   $nilai3=0;
  }
  elseif($x>$b[nilai2] and $x<$b[nilai3])
  {
   $nilai1=$nilaiturun1;
   $nilai2=$nilainaik1;
   $nilai3=0;
   $predikat1=$b[atr2];
   }

  elseif($x>$b[nilai3] and $x<$b[nilai33] )
  {
   $nilai1=0;
   $nilai2=1;
   $nilai3=0;
   $predikat1=$b[atr3];
  } 
}



// Kondisi 2 

else 
{
  if($x<=$b[nilai11])
  {
   $predikat1=$b[atr1];
   $nilai1=1;
   $nilai2=0;
   $nilai3=0;
  }
  elseif($x>$b[nilai2] and $x<$b[nilai11])
  {
   $nilai1=$nilaiturun1;
   $nilai2=$nilainaik1;
   $nilai3=0;
   $predikat1=$b[atr2];
  }
  elseif($x==$b[nilai11])
  {
   $nilai1=0;
   $nilai2=1;
   $nilai3=0;
   $predikat1=$b[atr2];
  }

  elseif($x>$b[nilai11] and $x<$b[nilai22])
  {
   $nilai1=0;
   $nilai2=$nilaiturun2;
   $nilai3=$nilainaik2;
   $predikat1=$b[atr2];
  }
  elseif($x>$b[nilai3] and $x<$b[nilai33])
  {
   $nilai1=0;
   $nilai2=0;
   $nilai3=1;
   $predikat1=$b[atr3];
  }
}

/*echo $predikat1;
echo $nilai1;
echo $nilai2;
echo $nilai3;*/
//exit();
 ////////skrip input nilai fuzzy variabel ke dalam tabel nilai////////////////////////////////////////
mysql_query("update nilai set predikat='$predikat1',nilai1='$nilai1',nilai2='$nilai2',nilai3='$nilai3' where idpasien='$_GET[id]' and idvariabel='$b[0]'  ");
//////----------------------------------------------------------------------------
}
header("location:hasil.php?id=$_GET[id]");
?>