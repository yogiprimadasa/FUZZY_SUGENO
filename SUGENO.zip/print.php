<script language="javascript">
javascript:print();
</script>