<?php
session_start();
if($_SESSION['id_user'] == '') {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
<style type="text/css">
<!--
.style5 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Rule ( Aturan )</strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="right"><a href="inputrule.php" class="button_default_aw">Input Rule </a></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><table width="100%" border="1" align="left" class="_css_font_default_11">
        <tr bgcolor="#666666">
                <td width="32"><div align="center" class="style5">No.</div></td>
                <td width="90"><div align="center" class="style5">Nama Rule</div></td>
                <td width="637"><div align="center" class="style5"> Aturan (Rule) </div></td>
                  <td width="103"><div align="center"><span class="style5">Aksi</span></div></td>
              </tr>
                <?php
					  $a=mysql_query("select * from rule");
					  $no=1;
					  while($b=mysql_fetch_array($a))
					  {
						$var1=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$b[idvariabel]'"));
						$var2=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$b[idvariabel1]'"));
						$var3=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$b[idvariabel2]'"));
						$var4=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$b[idvariabel3]'"));
						$var5=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$b[idvariabel4]'"));
					  ?>
                <tr>
                  <td><?php echo"$no"; ?>.</td>
                  <td><div align="center"><?php echo"$b[0]"; ?></div></td>
                  <td><?php
              $z=mysql_num_rows(mysql_query("select * from tmp_rule where idrule='$b[0]'"));	
			  $c=mysql_query("select * from tmp_rule where idrule='$b[0]' order by idvariabel asc");			  
			  $i=1;
			  while($d=mysql_fetch_array($c))
			  {
		        $e=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$d[idvariabel]'"));
				if($i==$z)
				{
				 echo"$e[variabel] <font color=black>$d[rule1]</font> ";echo" Then <font color=brown><strong>$b[maka]</strong></font>";
				}
				else
				{
				 echo"$e[variabel] <font color=black>$d[rule1]</font> <font color=red>And</font> ";
				}
				$i++;
			  }
				
              ?></td>
                  <td><div align="center"><a href="editrule.php?id=<?php echo"$b[0]"; ?>" title="Edit Data Aturen (Rule)" class="linkbawah"><img src='images/icon_edit.gif' alt="" width='16' height='16' border='0'></a>|
                    <a  onclick="return confirm ('Anda yakin akan menghapus Data Ini ?')" href="hapusrule.php?id=<?php echo"$b[0]"; ?>" title="Hapus Variabel"><img src='images/icon_delete.gif' alt="" width='16' height='16' border='0'></a><a class="linkbawah" onClick="return confirm ('Anda yakin akan menghapus Data Ini ?')" href="hapusrule.php?id=<?php echo $b[0]?>" title="Hapus Data Aturen (Rule)"></a></div></td>
                </tr>
                <?php
					  $no++;
					  }
					  ?>
          </table></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
 
</table>
<p>&nbsp;</p>
</body>
</html>


