<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
<style type="text/css">
<!--
.style5 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Daftar Hasil Diagnosa</strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><table width="100%" border="1" align="left" class="_css_font_default_11">
              <tr bgcolor="#333333">
                <td width="40" height="20"><div align="center" class="style5">No.</div></td>
                <td width="196"><div align="center" class="style5">Nama </div></td>
                <td width="176"><div align="center" class="style5">Alamat </div></td>
                <td width="175"><div align="center" class="style5">Email </div></td>
                <td width="187"><div align="center" class="style5">Hasil</div></td>
                <td width="76"><div align="center" class="style5">Aksi</div></td>
              </tr>
              <?php
			  			$nama=$_SESSION['nama'];
					  $a=mysql_query("select * from user where nama='$nama' order by idpasien asc");
					  
					  
					  $no=1;
					  while($b=mysql_fetch_array($a))
					  
					  //$idpasien2=$b['idpasien'];
					  
					  
					  {
					  ?>
              <tr>
                <td><div align="left"><?php echo"$no"; ?>.</div></td>
                <td><div align="left"><?php echo"$b[nama]"; ?></div></td>
                <td><div align="left"><?php echo"$b[alamat]"; ?></div></td>
                <td><div align="left"><?php echo"$b[email]"; ?></div></td>
                <td>
                  <div align="left">
                    <?php
					$idpasien2=$b["idpasien"];
					//echo $idpasien2;
//$nama2=$_SESSION[$idpasien2];
$def1=mysql_fetch_array(mysql_query("select * from defuzzy where idpasien='$idpasien2'"));
$defuzzy=$def1[defuzzy];
$solusi=mysql_fetch_array(mysql_query("select * from var_output "));
// 0-20
if($defuzzy>1 and $defuzzy<=10 )
{
 $naik=0;
 $turun=1;
 $solusi1=$solusi[atr1];
 $kendali=$solusi[kendali1];
}
// 20-30
elseif($defuzzy>10 and $defuzzy<=20)
{
 $naik=($defuzzy-$solusi[nilai2])/($solusi[nilai11]-$solusi[nilai2]);
 $turun=($solusi[nilai11]-$defuzzy)/($solusi[nilai11]-$solusi[nilai2]);
 if($naik<=$turun)
 {
  $solusi1=$solusi[atr2];
  $kendali=$solusi[kendali2];
 }
 else
 {
  $solusi1=$solusi[atr2];
  $kendali=$solusi[kendali2];
 }
}
// 30-50
elseif($defuzzy>20 and  $defuzzy<=30)
{
 $naik=($defuzzy-$solusi[nilai11])/($solusi[nilai22]-$solusi[nilai11]);
 $turun=($solusi[nilai22]-$defuzzy)/($solusi[nilai22]-$solusi[nilai11]);
 if($naik<=$turun)
 {
  $solusi1=$solusi[atr3];
  $kendali=$solusi[kendali3];
 }
 else
 {
  $solusi1=$solusi[atr3];
  $kendali=$solusi[kendali3];
 }
}
/////////////////////////////////

echo"Hasil Penilaian : $solusi1";



?>
                  </div></td>
                <td><div align="center"><a href="hasil1.php?id=<?php echo"$b[0]"; ?>" title=""></a><a onClick="return confirm ('Anda yakin akan menghapus Data Ini ?')" href="hapushistory.php?id=<?php echo $b[0]?>" title=""><img src='images/icon_delete.gif' width='16' height='16' border='0'></a></div></td>
              </tr>
              <?php
					  $no++;
					  }
					  ?>
          </table></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
  
  
</table>
<p>&nbsp;</p>
</body>
</html>


