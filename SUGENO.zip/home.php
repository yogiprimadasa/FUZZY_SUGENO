<?php
session_start();
if($_SESSION['id_user'] == '') {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}
?>
<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
<style type="text/css">
<!--
.style1 {
	font-size: 12
}
.style2 {font-size: 14px}
-->
</style>
</head>
<body  bgcolor="#e9e9e9"><table width="949" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="947" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
        <tr>
        <th scope="col">&nbsp;</th>
        <th align="left" class="_css_font_default_11" scope="col"><strong>Home</strong></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" width="890" height="7"></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="center"><strong><span class="style2">DIAGNOSA PENYAKIT DIABETES MELLITUS menggunakan FUZZY SUGENO Pada RSIA Evasari </span><br><br>
        </strong></div>
          <div align="left"><strong>Penerapan Metode Sugeno </strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
      
        <th scope="col">&nbsp;</th>
       <th align="left" class="_css_font_default_11" scope="col"><div align="justify">
         <p class="style1">Jumlah penderita Diabetes Mellitus meningkat dari tahun ke tahun. Hal ini dikarenakan keterlambatan diagnosis penyakit dan juga karena gaya hidup yang tidak sehat. Penderita penyakit tersebut biasanya tidak menyadari kalau menderita penyakit Diabetes Mellitus. Pada penelitian ini, dibuat suatu sistem penegakan penyakit Diabetes Mellitus dengan Metode Sugeno. Variabel-variabel pendukung penegakan diagnosis penyakit tersebut digunakan dalam pembentukan himpunan fuzzy. Himpunan fuzzy itu akan diproses dengan Metode Sugeno sehingga<br>
           menghasilkan suatu keputusan.</p>
         <p class="style1"> Aplikasi yang dirancang telah diuji dengan melibatkan rekam medik diagnosa dari dokter, hasil keputusan yang dihasilkan aplikasi adalah sama dengan diagnosa dokter yang tertera di rekam medik. Secara umum aplikasi berbasis web ini bisa digunakan sebagai alat bantu dalam penegakan diagnosis penyakit Diabetes Mellitus). </p>
       </div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
       
      
      <tr>
        <th height="19" scope="col">&nbsp;</th>
        <th align="left" class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" width="100%"></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left" class="_css_font_default_11_b">
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
 
</table>
<p>&nbsp;</p>
</body>
</html>


