<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
 
////////////////////
mysql_query("update rule set maka='$_POST[then]',daerah='$_POST[daerah]' where idrule='$_POST[idrule]'");
$idvar=$_POST[idvar];
$b=count($idvar);
$i=0;
while ($i<$b) 
{
$w=$zz;
$idvar=$_POST[idvar];
$rule1=$_POST[rule1];
$idrule1=$_POST[idrule1];
mysql_query("update tmp_rule set tmp_rule='$rule1[$i]' where idrule='$idrule1[$i]' and idvariabel='$idvar[$i]'");
$i++;
}
/////////////////////////
 
 
 
 
 header("location:rule.php");
?>