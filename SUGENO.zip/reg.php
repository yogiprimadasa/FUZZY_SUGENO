<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}


include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
 
<style type="text/css">
<!--
.style2 {color: #FFFFFF; font-weight: bold; }
.style4 {font-weight: bold}
-->
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#e9e9e9">
<table width="949" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="947" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Konsultasi</strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form action="savereg.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
              <table width="100%" border="0" align="left" class="_css_font_default_12">
                <tr>
                  <td colspan="3" bgcolor="#333333"><span class="style2">Input Data Diri Anda : </span></td>
                </tr>
                <tr>
                  <td width="68">Nama Anda</td>
                  <td width="8">:</td>
                  <td width="800"><input name="a" type="text" id="a" size="40" value="<?php echo $_SESSION['nama']; ?>"  /></td>
                </tr>
                <tr>
                  <td>Alamat</td>
                  <td>:</td>
                  <td><textarea name="b" cols="35" rows="3" id="b"></textarea></td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>:</td>
                  <td><input name="c" type="text" id="c" size="40"  /></td>
                </tr>

                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><table width="100%" border="0" align="left" class="_css_font_default_12">
                      <tr bgcolor="#333333">
                        <td width="26"><div align="center" class="style2">
                            <div align="center" class="style4">No.</div>
                        </div></td>
                        <td bgcolor="#333333"><div align="center" class="style4 style2">Input Nilai Gejala </div></td>
                      </tr>
                      <?php
					  $a=mysql_query("select * from variabel order by idvariabel asc");
					  $no=1;
					  while($b=mysql_fetch_array($a))
					  {
					  ?>
                      <tr>
                        <td><?php echo"$no"; ?>.</td>
                        <td rowspan="2"><div align="left">
                            <table width="100%" border="0" align="center" class="_css_font_default_12">
                              <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td><strong><?php echo"$b[1]"; ?></strong></td>
                              </tr>
                              <tr>
                                <td width="59" height="24">Nilai</td>
                                <td width="13"><strong>:</strong></td>
                            <td width="762"><input name="idvar[]" type="hidden" id="idvar[]" value="<?php echo"$b[0]"; ?>" />
                             
                              <input name="nilai[]" type="text" id="nilai[]" maxlength="3" />
                              </td>
                              </tr>
                              <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td><?php 
					 echo"$b[atr1] = $b[nilai1]-$b[nilai11]<br />"; 
                     echo"$b[atr2] = $b[nilai2]-$b[nilai22]<br />"; 
                       echo"$b[atr3] =$b[nilai3]-$b[nilai33]<br />"; 
					 ?></td>
                              </tr>
                            </table>
                        </div></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td colspan="2">&nbsp;</td>
                      </tr>
                      <?php
					  $no++;
					  }
					  ?>
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="submit" class="button_default_aw" name="Submit3" value="Diagnosa" />
                  <input type="reset" class="button_default_aw" name="Submit222" value="Ulangi" />
                  <input type="button" class="button_default_aw" name="Submit32" value="Kembali" onClick="self.history.back()"/></td>
                </tr>
              </table>
            </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" width="100%" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
  
  
</table>
<p>&nbsp;</p>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
</script>
</body>
</html>


