<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");

?>

<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
<style type="text/css">
<!--
.style2 {color: #FFFFFF; font-weight: bold; }
.style4 {font-weight: bold}
-->
</style>
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php 
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Input Nilai </strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><form action="savenilai.php?id=<?php echo"$_GET[id]"; ?>" method="post" enctype="multipart/form-data" name="form1" id="form1">
              <table width="850" border="0" align="left" class="_css_font_default_11">
                <?php
			  $a=mysql_fetch_array(mysql_query("select * from user where idpasien='$_GET[id]'"));
			  ?>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td width="121">Nama</td>
                  <td width="30">:</td>
                  <td width="380"><?php echo"$a[1]"; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Alamat</td>
                  <td>:</td>
                  <td><?php echo"$a[2]"; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>:</td>
                  <td><?php echo"$a[3]"; ?></td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
              </table>
              <table width="851" border="0" align="left" class="_css_font_default_11">
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td width="1">&nbsp;</td>
                  <td width="120"><?php
					  $a=mysql_fetch_array(mysql_query("select * from variabel order by idvariabel asc limit 0,1")); echo"$a[1]"; 
					  ?>
                    <input name="idvar1" type="hidden" id="idvar1" value="<?php echo"$a[0]"; ?>" /></td>
                  <td width="716">&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><input name="nilai1" type="text" id="nilai1" size="20" /></td>
                  <td><?php echo"$a[atr1] = $a[nilai1]-$a[nilai11]<br />"; 
                     echo"$a[atr2] = $a[nilai2]-$a[nilai22]"; 
					 if(empty($a[atr3])) { } else { 
                     echo"<br />$a[atr3] = $a[nilai3]-$a[nilai33]"; }	 
					 
					 
					 ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><?php
					  $a=mysql_fetch_array(mysql_query("select * from variabel order by idvariabel asc limit 1,1")); echo"$a[1]"; 
					  ?>
                    <input name="idvar2" type="hidden" id="idvar2" value="<?php echo"$a[0]"; ?>" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><input name="nilai2" type="text" id="nilai2" size="20" /></td>
                  <td><?php echo"$a[atr1] = $a[nilai1]-$a[nilai11]<br />"; 
                     echo"$a[atr2] = $a[nilai2]-$a[nilai22]"; 
					 if(empty($a[atr3])) { } else { 
                     echo"<br />$a[atr3] = $a[nilai3]-$a[nilai33]"; }	 
					 
					 
					 ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><?php
					  $a=mysql_fetch_array(mysql_query("select * from variabel order by idvariabel asc limit 2,1")); echo"$a[1]"; 
					  ?>
                    <input name="idvar3" type="hidden" id="idvar3" value="<?php echo"$a[0]"; ?>" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><input name="nilai3" type="text" id="nilai3" size="20" /></td>
                  <td><?php echo"$a[atr1] = $a[nilai1]-$a[nilai11]<br />"; 
                     echo"$a[atr2] = $a[nilai2]-$a[nilai22]"; 
					 if(empty($a[atr3])) { } else { 
                     echo"<br />$a[atr3] = $a[nilai3]-$a[nilai33]"; }	 
					 
					 
					 ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><?php
					  $a=mysql_fetch_array(mysql_query("select * from variabel order by idvariabel asc limit 3,1")); echo"$a[1]"; 
					  ?>
                    <input name="idvar4" type="hidden" id="idvar4" value="<?php echo"$a[0]"; ?>" /></td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><input name="nilai4" type="text" id="nilai4" size="20" /></td>
                  <td><?php echo"$a[atr1] = $a[nilai1]-$a[nilai11]<br />"; 
                     echo"$a[atr2] = $a[nilai2]-$a[nilai22]"; 
					 if(empty($a[atr3])) { } else { 
                     echo"<br />$a[atr3] = $a[nilai3]-$a[nilai33]"; }	 
					 
					 
					 ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><?php
					  $a=mysql_fetch_array(mysql_query("select * from variabel order by idvariabel asc limit 4,1")); echo"$a[1]"; 
					  ?>
                    <input name="idvar5" type="hidden" id="idvar5" value="<?php echo"$a[0]"; ?>" /></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td><input name="nilai5" type="text" id="nilai5" size="20" /></td>
                  <td><?php echo"$a[atr1] = $a[nilai1]-$a[nilai11]<br />"; 
                     echo"$a[atr2] = $a[nilai2]-$a[nilai22]"; 
					 if(empty($a[atr3])) { } else { 
                     echo"<br />$a[atr3] = $a[nilai3]-$a[nilai33]"; }	 
					 
					 
					 ?></td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3"><div align="center">
                    <input type="submit" name="Submit" value="Hitung" />
                    <input type="reset" name="Submit22" value="Ulangi" />
                    <input type="button" name="Submit" value="Kembali" onClick="self.history.back()"/>
                  </div></td>
                </tr>
              </table>
            </form></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      

      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"> 
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
</table>
<p>&nbsp;</p>
</body>
</html>


