<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
$r=mysql_num_rows(mysql_query("select * from rule where idrule='$_POST[rule]'"));
if($r!==0)
{
 echo"<center><font color=red>Aturan (Rule) $_POST[idrule] Sudah Ada....!!!!<br><br>
 <input type=button value=Kembali onclick=self.history.back()>";
}
else
{
////////////////////
mysql_query("insert into rule values ('$_POST[idrule]','$_POST[then]','$_POST[daerah]')");
$z=mysql_fetch_array(mysql_query("select * from rule where idrule='$_POST[idrule]'"));
$zz=$z[0];


$idvar=$_POST[idvar];
$b=count($idvar);
$i=0;
while ($i<$b) 
{
$w=$zz;
$idrule=$_POST[idrule];
$idvar=$_POST[idvar];
$rule=$_POST[rule];
mysql_query("insert into tmp_rule values('$w','$idvar[$i]','$rule[$i]')");
$i++;
}
/////////////////////////
 
 
 
 
 header("location:rule.php");
}
?>