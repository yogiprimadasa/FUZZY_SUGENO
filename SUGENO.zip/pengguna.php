<?php
session_start();
if($_SESSION['id_user'] == '') {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
include_once("function/function_pengguna.php");
?>
<html>
<head>	
<link rel="stylesheet" href="css/serverstyle.css">
<link rel="stylesheet" href="css/button.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-base.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-topbar.css" />
<link rel="stylesheet" type="text/css" href="ddlevelsfiles/ddlevelsmenu-sidebar.css" />
<script type="text/javascript" src="ddlevelsfiles/ddlevelsmenu.js"></script>
 
</head>
<body  bgcolor="#e9e9e9">
<table width="940" border="0" align="center" cellpadding="0" cellspacing="0" class="BorderBox_NoColor">
  <!--DWLayoutTable-->
  <tr>
    <td height="147" colspan="3" align="left" valign="top" bgcolor="#f4f4f4"><img src="images/header.png" width="100%" height="160"></td>
  </tr>
  
  <tr>
    <td width="1028" height="173" colspan="3" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <th bgcolor="#414141" scope="col">&nbsp;</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">
		  <?php
		    include "menu.php"; 
		  ?>		</th>
        <th bgcolor="#414141" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th width="25" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th width="25" class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left">Selamat Datang, <strong><?php echo $_SESSION['nama']; ?></strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><strong>Tabel Pengguna </strong></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><a href="pengguna_add.php" class="button_default_aw">Add New Pengguna</a></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">
		<div align="left">
		  <table width="100%" border="1" cellpadding="1" cellspacing="1" class="BorderBox_NoColor">
            <tr>
              <td width="4%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>No</strong></div></td>
              <td width="20%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Nama</strong></div></td>
              <td width="19%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Username</strong></div></td>
              <td width="18%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Password</strong></div></td>
              <td width="24%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Email</strong></div></td>
              <td width="9%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Jenis Kelamin</strong></div></td>
              <td width="6%" bgcolor="#666666" class="_css_font_default_12"><div align="center" class="_css_font_default_11_blue"><strong>Action</strong></div></td>
            </tr>
			
			<?php
		$pengguna = select_pengguna();
		$nomor=1;
		for ($i=0;$i<count($pengguna);$i++) {
			
				$current_id_pengguna = $pengguna[$i][0];
				$current_nama = $pengguna[$i][1];
				$current_email = $pengguna[$i][2];
				$current_username = $pengguna[$i][3];
				$current_password = $pengguna[$i][4];
				$current_jenis_kelamin = $pengguna[$i][5];
				$current_alamat = $pengguna[$i][6];
				$current_hak_akses = $pengguna[$i][7];				
 
				
				echo "<tr>";
				  echo "<td><div align='center' class='_css_font_default_link_11 style1'>$nomor</div></td>";
				  echo "<td><div align='left' class='_css_font_default_link_11 style1'>$current_nama</div></td>";
				   echo "<td><div align='left' class='_css_font_default_link_11 style1'>$current_username</div></td>";
				    echo "<td><div align='left' class='_css_font_default_link_11 style1'>$current_password</div></td>";
					 echo "<td><div align='left' class='_css_font_default_link_11 style1'>$current_email</div></td>";
					 echo "<td><div align='left' class='_css_font_default_link_11 style1'>$current_jenis_kelamin </div></td>";
				  echo "<td>";
				  echo "<div align='center'>";
				  echo "<a href='pengguna_edit.php?id=$current_id_pengguna'><img src='images/icon_edit.gif' width='16' height='16' border='0'></a>&nbsp;";
				  echo "<a href='pengguna_delete.php?id=$current_id_pengguna'><img src='images/icon_delete.gif' width='16' height='16' border='0'></a>";
				  echo "</div>";
				  echo "</td>";
				echo "</tr>";
				$nomor++;
			}
			?>
          </table>
		</div>		</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th height="19" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left"><img src="images/line_full.gif" ></div></th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <th scope="col">&nbsp;</th>
        <th class="_css_font_default_11" scope="col"><div align="left" class="_css_font_default_11_b">
          <div align="center">
            <?php include_once("copyright.php"); ?>
          </div>         </th>
        <th class="_css_font_default_11" scope="col">&nbsp;</th>
        </tr>
      
    </table></td>
  </tr>
  
</table>
<p>&nbsp;</p>
</body>
</html>


