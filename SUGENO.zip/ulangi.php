<?php
include"lib/config.php";
mysql_query("delete from nilai where idpasien='$_GET[id]'");
mysql_query("delete from defuzzy where idpasien='$_GET[id]'");
mysql_query("delete from tmp_min where idpasien='$_GET[id]'");
header("location:var1.php?id=$_GET[id]");
?>
