<?php
include"lib/config.php";
$a=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$_POST[idvar1]'"));
$b=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$_POST[idvar2]'"));
$c=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$_POST[idvar3]'"));
$d=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$_POST[idvar4]'"));
$e=mysql_fetch_array(mysql_query("select * from variabel where idvariabel='$_POST[idvar5]'"));

	
mysql_query("insert into nilai values('','$_GET[id]','$_POST[idvar1]','$_POST[nilai1]','','','','')");
mysql_query("insert into nilai values('','$_GET[id]','$_POST[idvar2]','$_POST[nilai2]','','','','')");
mysql_query("insert into nilai values('','$_GET[id]','$_POST[idvar3]','$_POST[nilai3]','','','','')");
mysql_query("insert into nilai values('','$_GET[id]','$_POST[idvar4]','$_POST[nilai4]','','','','')");
mysql_query("insert into nilai values('','$_GET[id]','$_POST[idvar5]','$_POST[nilai5]','','','','')");

header("location:savenilai1.php?id=$_GET[id]");
?>