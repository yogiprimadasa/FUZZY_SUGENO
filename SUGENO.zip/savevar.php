<?php
session_start();
if(!session_is_registered('id_user')) {
	echo '<script language="javascript">alert("Session tidak ditemukan, Silahkan Login !")</script>';
	echo '<script language="javascript">window.location = "logout.php"</script>';		
}

include_once("lib/config.php");
if(empty($_POST[variabel]))
{
 echo"<center><font color=red>Variabel Belum Diisi....!!!!<br><br>
 <input type=button value=Kembali onclick=self.history.back()>";
}
else
{
 mysql_query("update variabel set variabel='$_POST[variabel]',
 nilai1='$_POST[a]',nilai11='$_POST[b]',
 nilai2='$_POST[c]',nilai22='$_POST[d]',
 nilai3='$_POST[e]',nilai33='$_POST[f]',
 
 atr1='$_POST[atr1]',atr2='$_POST[atr2]',atr3='$_POST[atr3]' where idvariabel='$_GET[id]'");
 header("location:var.php");
}
?>