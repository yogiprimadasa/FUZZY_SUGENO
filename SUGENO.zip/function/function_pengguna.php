<?php

function select_pengguna(){ 
	$sql="SELECT * FROM admin" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_id_pengguna($var_id_pengguna){ 
	$sql="SELECT * FROM admin WHERE id_pengguna = '" .mysql_real_escape_string(trim($var_id_pengguna)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_nama($var_nama){ 
	$sql="SELECT * FROM admin WHERE nama = '" .mysql_real_escape_string(trim($var_nama)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_email($var_email){ 
	$sql="SELECT * FROM admin WHERE email = '" .mysql_real_escape_string(trim($var_email)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_username($var_username){ 
	$sql="SELECT * FROM admin WHERE username = '" .mysql_real_escape_string(trim($var_username)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_password($var_password){ 
	$sql="SELECT * FROM admin WHERE password = '" .mysql_real_escape_string(trim($var_password)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_jenis_kelamin($var_jenis_kelamin){ 
	$sql="SELECT * FROM admin WHERE jenis_kelamin = '" .mysql_real_escape_string(trim($var_jenis_kelamin)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_alamat($var_alamat){ 
	$sql="SELECT * FROM admin WHERE alamat = '" .mysql_real_escape_string(trim($var_alamat)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_pengguna_by_hak_akses($var_hak_akses){ 
	$sql="SELECT * FROM admin WHERE hak_akses = '" .mysql_real_escape_string(trim($var_hak_akses)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_pengguna_by_id_pengguna($var_id_pengguna){ 
	$sql="DELETE FROM admin WHERE id_pengguna = " .mysql_real_escape_string(trim($var_id_pengguna)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_pengguna=1; } else { $returnDetete_pengguna=0; }
	return $returnDetete_pengguna;
}

function insert_pengguna($var_nama,$var_email,$var_username,$var_password,$var_jenis_kelamin,$var_alamat,$var_hak_akses){ 
	$sql="INSERT INTO admin (id_pengguna,nama,email,username,password,jenis_kelamin,alamat,hak_akses) VALUES (NULL,'" .mysql_real_escape_string(trim($var_nama)). "','" .mysql_real_escape_string(trim($var_email)). "','" .mysql_real_escape_string(trim($var_username)). "','" .mysql_real_escape_string(trim($var_password)). "','" .mysql_real_escape_string(trim($var_jenis_kelamin)). "','" .mysql_real_escape_string(trim($var_alamat)). "','" .mysql_real_escape_string(trim($var_hak_akses)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_pengguna=1; } else { $returnInsert_pengguna=0; }
	return $returnInsert_pengguna;
}

function update_pengguna($var_id_pengguna,$var_nama,$var_email,$var_username,$var_password,$var_jenis_kelamin,$var_alamat,$var_hak_akses){ 
	$sql="UPDATE admin SET nama = '" .mysql_real_escape_string(trim($var_nama)). "', email = '" .mysql_real_escape_string(trim($var_email)). "', username = '" .mysql_real_escape_string(trim($var_username)). "', password = '" .mysql_real_escape_string(trim($var_password)). "', jenis_kelamin = '" .mysql_real_escape_string(trim($var_jenis_kelamin)). "', alamat = '" .mysql_real_escape_string(trim($var_alamat)). "', hak_akses = '" .mysql_real_escape_string(trim($var_hak_akses)). "' WHERE id_pengguna = '" .mysql_real_escape_string(trim($var_id_pengguna)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_pengguna=1; } else { $returnUpdate_pengguna=0; }
	return $returnUpdate_pengguna;
}

?>