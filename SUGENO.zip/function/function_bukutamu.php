<?php

function select_bukutamu(){ 
	$sql="SELECT * FROM bukutamu ORDER by id_bukutamu DESC" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_id_bukutamu($var_id_bukutamu){ 
	$sql="SELECT * FROM bukutamu WHERE id_bukutamu = '" .trim($var_id_bukutamu). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_id_pengguna($var_id_pengguna){ 
	$sql="SELECT * FROM bukutamu WHERE id_pengguna = '" .trim($var_id_pengguna). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_komentar($var_komentar){ 
	$sql="SELECT * FROM bukutamu WHERE komentar = '" .trim($var_komentar). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_email($var_email){ 
	$sql="SELECT * FROM bukutamu WHERE email = '" .trim($var_email). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_alamat($var_alamat){ 
	$sql="SELECT * FROM bukutamu WHERE alamat = '" .trim($var_alamat). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bukutamu_by_tanggaljam($var_tanggaljam){ 
	$sql="SELECT * FROM bukutamu WHERE tanggaljam = '" .trim($var_tanggaljam). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_bukutamu_by_id_bukutamu($var_id_bukutamu){ 
	$sql="DELETE FROM bukutamu WHERE id_bukutamu = " .trim($var_id_bukutamu). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_bukutamu=1; } else { $returnDetete_bukutamu=0; }
	return $returnDetete_bukutamu;
}

function insert_bukutamu($var_id_pengguna,$var_komentar,$var_email,$var_alamat,$var_tanggaljam){ 
	$sql="INSERT INTO bukutamu (id_bukutamu,id_pengguna,komentar,email,alamat,tanggaljam) VALUES (NULL,'" .trim($var_id_pengguna). "','" .trim($var_komentar). "','" .trim($var_email). "','" .trim($var_alamat). "','" .trim($var_tanggaljam). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_bukutamu=1; } else { $returnInsert_bukutamu=0; }
	return $returnInsert_bukutamu;
}

function update_bukutamu($var_id_bukutamu,$var_id_pengguna,$var_komentar,$var_email,$var_alamat,$var_tanggaljam){ 
	$sql="UPDATE bukutamu SET id_pengguna = '" .trim($var_id_pengguna). "', komentar = '" .trim($var_komentar). "', email = '" .trim($var_email). "', alamat = '" .trim($var_alamat). "', tanggaljam = '" .trim($var_tanggaljam). "' WHERE id_bukutamu = '" .trim($var_id_bukutamu). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_bukutamu=1; } else { $returnUpdate_bukutamu=0; }
	return $returnUpdate_bukutamu;
}

?>