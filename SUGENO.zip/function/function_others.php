<?php

 

	function login($u,$p){ 
		$sql="SELECT * FROM admin  WHERE username = '" .trim($u). "'  and password = '" .trim($p). "' LIMIT 1 ";
		$resultQuery=mysql_query($sql);
		while ($rows=mysql_fetch_row($resultQuery)){ 
			$data[] = $rows;
		}
		return $data;
	}


?>